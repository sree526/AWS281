homeapp.controller('AppCtrl', function($scope, $http,socket) {  
  $scope.getdata=function(){

	  socket.on('livestream', function(data) {
	   console.log(data);
	  });
  };
});
