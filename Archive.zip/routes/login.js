/**
 * http://usejsdoc.org/
 */
exports.home=function(req,res){
	res.render('homepage');
}